package usc.edu.eq.user;

public class Guest { // Guests can join rooms but not enqueue
}
