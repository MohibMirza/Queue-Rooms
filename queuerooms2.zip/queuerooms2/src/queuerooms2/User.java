package queuerooms2;

import java.util.List;
import java.util.Map;

public class User {
	
	
	
	public String userID;
	public String fullname;
	public String username; 
	
	
	
}
