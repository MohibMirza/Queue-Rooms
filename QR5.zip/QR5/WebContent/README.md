# Queue-Rooms
To see the demo, download all files in this branch and open index.html

custom.css in css folder contains styleing for the chat box.
