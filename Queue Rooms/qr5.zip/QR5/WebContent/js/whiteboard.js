/**
 * 
 */

	var firebaseConfig = {
		apiKey: "AIzaSyDCm3yLjNFmA_irCAmk54tQVmr8lhf1PJc",
		authDomain: "mytest1-ab6ae.firebaseapp.com",
		databaseURL: "https://mytest1-ab6ae.firebaseio.com",
		projectId: "mytest1-ab6ae",
		storageBucket: "mytest1-ab6ae.appspot.com",
		messagingSenderId: "628828202676",
		appId: "1:628828202676:web:5a63c783999939d00719e1",
		measurementId: "G-H77E4RTWY5"
	};
	if (!firebase.apps.length) {
		firebase.initializeApp(firebaseConfig);
	}
	
	var database = firebase.database();
	
	var _canvasRef = database.ref().child('canvas');
	
	
	var canvas = document.getElementById('drawCanvas');
	var ctx = canvas.getContext('2d');
	ctx.strokeStyle = "black";
	var isErase = false;
	
	canvas.addEventListener('mousedown', startDraw, false);
	canvas.addEventListener('mousemove', draw, false);
	canvas.addEventListener('mouseup', endDraw, false);
	// canvas.addEventListener('mouseout', endDraw, false);
	
	var isActive = false;
	
	var plotX = [];
	var plotY = [];
	var plotErase = [];
	
	addImage();
	
	function draw(e) {
		if(!isActive) return;
		
		var rect = canvas.getBoundingClientRect();
		
		//var x = e.clientX - canvas.offsetLeft;
		//var y = e.clientY - canvas.offsetTop;
		
		var x = e.clientX - rect.left;
		var y = e.clientY - rect.top;
		
		plotX.push(x);
		plotY.push(y);
		plotErase.push(isErase);
		
		drawOnCanvas(plotX, plotY);
	}
	
	function drawOnCanvas(xplot, yplot) {
		if(isErase) {
			startErase();
		} else {
			stopErase();
		}
		ctx.beginPath();
		
		if(!xplot.length || !yplot.length) return;
		
		ctx.moveTo(xplot[0], yplot[0]);
		for(var i=1; i<xplot.length; i++) {
			ctx.lineTo(xplot[i], yplot[i]);
		}
		
		ctx.stroke();
	}
	
	function startDraw(e) {
		/*
		prevX = currX;
		prevY = currY;
		currX = e.clientX - canvas.offsetLeft;
		currY = e.clientY - canvas.offsetTop;
		*/
		isActive = true;
	}
	
	function endDraw(e) {
		isActive = false;
		plotX = [];
		plotY = [];
		plotErase = [];
		writeCanvas();
	}

	function startErase(e) {
		ctx.strokeStyle = "white";
		isErase = true;
		ctx.lineWidth = '20';
	}
	
	function stopErase(e) {
		ctx.strokeStyle = "black";
		isErase = false;
		ctx.lineWidth = '1';
	}

	function serialize(canvas) {
		return canvas.toDataURL();
	}
	
	function deserialize(data, canvas) {
		var img = new Image();
		img.onload = function() {
			canvas.width = img.width;
			canvas.height = img.height;
			console.log("nice");
			canvas.getContext("2d").drawImage(img, 0, 0);
		};

		img.src = data;
	}
	
	function addImage() {
		var pictureCanvasId = "drawCanvas";
		var canvas1 = document.getElementById(pictureCanvasId);
		_canvasRef.on('value',function(snapshot) {
			deserialize(snapshot.val().canvas, canvas1);
		})
		
	}
	
	function writeCanvas(e) {
		var canvasContent = serialize(canvas);
		_canvasRef.set({
			canvas: canvasContent
		}, function(e){
			
		});
		
	}