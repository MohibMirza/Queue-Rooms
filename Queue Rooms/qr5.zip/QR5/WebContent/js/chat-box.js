/**
 * 
 */

// Your web app's Firebase configuration
				var _firebaseConfig = {
				    apiKey: "AIzaSyDvbLAmCUFiA94jVoh24h3M2Zw1REi1QjM",
				    authDomain: "cs201-project-c4168.firebaseapp.com",
				    databaseURL: "https://cs201-project-c4168.firebaseio.com/",
				    projectId: "cs201-project-c4168",
				    storageBucket: "cs201-project-c4168.appspot.com",
				    messagingSenderId: "747247541467",
				    appId: "1:747247541467:web:5efdb1140dca08111ec0fe",
				    measurementId: "G-TRH6PVHYGW"
				};
				// Initialize Firebase
				if (!firebase.apps.length) {
					firebase.initializeApp(_firebaseConfig);
				}
				
				
				var _state = {
					firechat: null,
					currUser: null,
					hasLoaded: false,
					roomId: null
				};
				
				function beginChat() {
					initChat(firebase.auth().currentUser);
				}
				
				function initChat(uid, displayName, photoURL) {
					// Get a Firebase Database ref
					var chatRef = firebase.database().ref("chat");

					// Create a Firechat instance
					var firechat = new Firechat(chatRef);
					firechat.on("room-enter", onRoomEntered);
					firechat.on("message-add", onReceiveMessage);
					// Set the Firechat user
					firechat.setUser(uid, displayName,
						function(userRef) {
							//firechat.resumeSession();
							_state.currUser = userRef;
							updateUserProfile(userRef, photoURL);
						});
					_state.firechat = firechat;
				}
				
				function updateUserProfile(user, photoUrl) {
					var chatRef = firebase.database().ref("chat/users/" + user.id);
			        chatRef.update({
			        	photoUrl: photoUrl
			        }, function(error) {
			            if (error) {
			                alert("Failed: " + JSON.stringify(error));
			            } else {
			                getUsers();
			            }
			        });
				}
				
				function onContactClicked(event) {
					var li = event.currentTarget;
					if(li.nodeName.toUpperCase() != "LI") {
						alert("Unknown node clicked: " + li.outerHTML);
						return;
					}
					
					chatWithFriend(li.id);
				}
				
				function chatWithFriend(friendId) {
					var roomName;
					if(friendId < _state.currUser.id) {
						roomName = friendId + " " + _state.currUser.id;
					}
					else {
						roomName = _state.currUser.id + " " + friendId;
					}
					createOrEnterRoom(roomName);
				}
				
				function getUsers() {
			    	var chatRef = firebase.database().ref("chat/users");
			        chatRef.on("value", function(snapshot) {
			        	var firstFriendId = null;
			        	if(!_state.hasLoaded) {
				    		var div = document.getElementById("contactList");
				        	for(var user in snapshot.val()) {
				        		// filter for friends
				        		
				        	    var userInfo = snapshot.val()[user];
				        	    if(_state.currUser.id == userInfo.id) {
				        	    	continue;
				        	    }
				        	    if (!firstFriendId) {
				        	    	firstFriendId = userInfo.id;
				        	    }
								var li = document.createElement("li");
								li.id = userInfo.id;
								li.className = "chatListRow row d-flex flex-row align";
								li.onclick = onContactClicked;
								var divProfile = document.createElement("div");
								divProfile.className = "chatListProfile";
								var img = document.createElement("img");
								img.className = "chatListProfilePicture rounded-circle";
								img.width = "20";
								if(userInfo.photoUrl)
								{							
									img.src = userInfo.photoUrl;
								}
								else {
									img.src = "timmy.png";
								}
								
								var name = document.createTextNode(userInfo.name);
								name.className = "chatListName";
								
								divProfile.appendChild(img);
								li.appendChild(divProfile);
								li.appendChild(name);
								div.appendChild(li);
				        	}
				        	_state.hasLoaded = true;
				        	
				        	if (firstFriendId){
				        		chatWithFriend(firstFriendId);
				        	}
			        	}
			        });
			    }	
				
				function onRoomEntered(roomId) {
					_state.roomId = roomId.id;
					_state.firechat.getRoom(roomId.id, function(room) {
						try {
							console.log("onRoomEntered: " + room.name);
							var roomName = room.name;
							var ids = roomName.split(" ");
							var friendId;
							if(ids[0] == _state.currUser.id) {
								friendId = ids[1];
							}
							else if (ids[1] == _state.currUser.id) {
								friendId = ids[0];
							}
							else {
								alert("Something went wrong!\n " + roomName);
								return;
							}
							var li = document.getElementById(friendId);
							var friendName = li.textContent;
							document.getElementById("chatHeaderRecipient").innerText = friendName;
						}
						catch (exception) {
							console.error("room enter exception", e.stack);
						}
					});
					
				}

				function sendTest(message) {
					// TODO: dynamic roomId generation
					_state.firechat.sendMessage(_state.roomId, message,
							messageType = 'default', function(foo) {
						
							});
				}
				
				function cleanRoom() {
					if (_state.roomId){
						document.getElementById("chatLog").innerHTML = "";
						_state.firechat.leaveRoom(_state.roomId);
						_state.roomId = null;
					}
				}
				
				function createOrEnterRoom(roomName) {
					_state.firechat.getRoomList(function(roomList) {
						var roomId = null;
						for(var id in roomList) {
							var g = roomList[id];
							if (g.name == roomName) {
								roomId = id;
								found = true;
								break;
							}
						}						
						
						if (_state.roomId) {
							if (roomId == _state.roomId) {
								console.log("Room unchanged: " + roomId);
								return;
							}
							else {
								cleanRoom();
							}
						}
							
						if(!roomId) {
							_state.firechat.createRoom(roomName, "public", function(roomId) {
							});
						}
						else {
							console.log("Entering room: " + roomId);
							_state.firechat.enterRoom(roomId);
						}
					});
					
				}
				
				
				function onReceiveMessage(roomId, message) {
					if(message.userId == _state.currUser.id) {
						displayMyMessage(message);
					}
					else {
						displayOtherMessage(message);
					}
				}
				
				function displayMyMessage(message) {
					var msg = "<li class='list-group-item' style='text-align: right'>"
						+ "<text class='userMessage'>"
						+ message.message
						+ "</text></li>";
					document.getElementById("chatLog").innerHTML += msg;
				}
				
				function displayOtherMessage(message) {
					var otherUser = message.userId;
			    	var chatRef = firebase.database().ref("chat/users/" + otherUser);
			        chatRef.on("value", function(snapshot) {
			        	var userInfo = snapshot.val();
			        	var li = document.createElement("li");
			        	li.className = "chatLogRow row d-flex flex-row";
			        	var profileDiv = document.createElement("div");
			        	profileDiv.className = "senderProfile";
			        	li.appendChild(profileDiv);
			        	var img = document.createElement("img");
			        	img.className = "senderProfilePicture rounded-circle";
			        	if (userInfo.photoUrl) {
			        		img.src = userInfo.photoUrl;
			        	}
			        	else {
			        		img.src = "timmy.png";
			        	}
			        	profileDiv.appendChild(img);
			        	var messageDiv = document.createElement("div");
			        	messageDiv.className = "senderMessage";
			        	li.appendChild(messageDiv);
			        	var messageText = document.createElement("text");
			        	messageText.innerText = message.message;
			        	messageDiv.appendChild(messageText);
						document.getElementById("chatLog").appendChild(li);
			        });
				}
				/*
				function login() {
			        // Log the user in via Google
			        var provider = new firebase.auth.GoogleAuthProvider();
			        firebase.auth().signInWithPopup(provider).then(function(result) {
				        // Once authenticated, instantiate Firechat with the logged in user
				        if (result.user) {
				          initChat(result.user);
				        }
			        }).catch(function(error) {
			          console.log("Error authenticating user:", error);
			        });
			        
			       // firebase.auth().onAuthStateChanged();
			    }
				
				login();
				*/
				
				
				//firebase.auth().onAuthStateChanged(function(user) {
				//	if (user) {
				//		console.log(user.id);
				//		initChat(user);
						// User is signed in.
				//	} else {
						// No user is signed in.
				//	}
				//});
				

				//_state.firechat.resumeSession();

				/* listen for "Enter" key press when chat box open */
				$("#messageToSend").keypress(function(event) {
					if (event.keyCode === 13) {
						event.preventDefault(); // disable new line function of enter key
						$("#sendButton").click(); // send message
					}
				});
				/* listen for "Enter" key press to search contact*/
				$("#searchContactBox").keypress(function(event) {
					if (event.keyCode === 13) {
						/* add implementation here to search for contact using keyword */
					}
				});
				function sendMessage() {
					var msg = document.getElementById("messageToSend").value;
					if (msg != "") {
						sendTest(msg);

						//displayMyMessage(msg);

						document.getElementById("messageToSend").value = '';
						document.getElementById("chatLog").scrollTop = document
								.getElementById("chatLog").scrollHeight;
						document.getElementById("messageToSend").placeholder = "Enter your message here..."
					} else {
						document.getElementById("messageToSend").placeholder = "Cannot send empty message! :("
					}
				}

				function displayMessages() {

				}
				var isHidden = true;
				function openChatBox() {
					isHidden = false;
					document.getElementById("chatBox").style.visibility = "visible";
					document.getElementById("chatButton").style.visibility = "hidden";
				}
				function closeChatBox() {
					isHidden = true;
					document.getElementById("chatBox").style.visibility = "hidden";
					document.getElementById("chatButton").style.visibility = "visible";
				}
				
				function toggleChatBox() {
					isHidden = !isHidden;
					if(!isHidden) {
						document.getElementById("chatBoxDiv").style.visibility = "visible";
					}
					else {
						document.getElementById("chatBoxDiv").style.visibility = "hidden";
					}
				}
				
				/*
				function sendTestMessage() {
					var msgString = "This is a test message.";
					sendTest(msgString);
					var testMsg = "<li class='chatLogRow row d-flex flex-row'> <div class='senderProfile'> <img class='senderProfilePicture rounded-circle' src=timmy.png> </div> <div class='senderMessage'><text>This is a test message.</text></div></li>"
					document.getElementById("chatLog").innerHTML += testMsg;
				}
				 */
				function addSampleContact(user) {
					var list = $('#chatList')[0];

				}